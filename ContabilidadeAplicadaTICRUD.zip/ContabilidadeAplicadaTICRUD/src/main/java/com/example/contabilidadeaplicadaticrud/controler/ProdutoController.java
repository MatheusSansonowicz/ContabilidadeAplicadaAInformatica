package com.example.contabilidadeaplicadaticrud.controler;

import org.springframework.stereotype.Controller;

@Controller
public class ProdutoController {
}
