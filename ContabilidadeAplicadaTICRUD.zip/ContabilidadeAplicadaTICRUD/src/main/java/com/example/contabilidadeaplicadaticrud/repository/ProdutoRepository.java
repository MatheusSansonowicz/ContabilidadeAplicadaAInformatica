package com.example.contabilidadeaplicadaticrud.repository;

public interface ProdutoRepository {
}
